let fotoObjetivo;
let clasificador;
let prediccion;
let confianza;

function preload(){
  //Load SpeechCommands18w sound Classifier model
  //classifier= ml5.soundClassifier("SpeechCommands18w", options);
  
  fotoObjetivo = loadImage("assets/michaelscott.jpg");
}

function setup() {
  createCanvas(400, 400);

  prediccion = document.getElementById("prediccion");
  
  confianza = document.getElementById("confianza");
    
  clasificador = ml5.imageClassifier("https://storage.googleapis.com/tm-model/9uASYKKml/model.json", listo); 
}

function listo(){
  console.log("estamos listo");
  clasificador.classify(fotoObjetivo, tengoResultados);
}
function tengoResultados(error, resultados){
  console.log("tengo resultados");
  if (error){
    console.log("pipipi");
  }
console.log(resultados[0].label);
  prediccion.innerHTML = resultados[0].label;
  confianza.innerHTML = resultados[0].confidence;
  
}


function draw() {
  background(0);
  image(fotoObjetivo, 0, 0, width, height)
}